# -*- coding: utf-8 -*-

import empro.toolkit.adv as adv

def main():
	path=r"C:/Users/Asus/Izhthu_mooditu_first_la_irundhu"
	lib=r"Izhthu_mooditu_first_la_irundhu_lib"
	subst=r"Izhthu_mooditu_first_la_irundhu_lib/substrate2.subst"
	substlib=r"Izhthu_mooditu_first_la_irundhu_lib"
	substname=r"substrate2"
	cell=r"coupled_line"
	view=r"layout"
	libS3D=r"simulation/Izhthu_mooditu_first_la_irundhu_lib/coupled_line/_3%D%Viewer/proj_libS3D.xml"
	varDictionary={}
	exprDictionary={}
	adv.loadDesign(path=path, lib=lib, subst=subst, substlib=substlib, substname=substname, cell=cell, view=view, libS3D=libS3D, var_dict=varDictionary, expr_dict=exprDictionary)
